Leyuan Loh:  leyuan <br />
Bo Sheng Lee: lee0717 <br /> <br />

we have implemented user interface/input for the assignment. The pc can now move according to the user's input. Apart from that, we also have a monster list and monster number counter. For our version, if the pc bang the wall or try to go to invalid location, the pc will skip a turn. Apart from that, Jeremy's code has a bug where the monster always move first. 