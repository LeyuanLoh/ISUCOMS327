### 3/10/21
* Start seperating job for assignment 1.05
* Lee -  complete the output of the dungeon using ncurses.h library and complete user input. The pc player now is able to move around
* Leyuan - created a function call stair_move in dungeon.c 
         - created count_monster function in dungeon.c
         - display monster number below the number
         - finalize everything
* Lee - Complete the monster list but have one problem where monster will move before pc move
