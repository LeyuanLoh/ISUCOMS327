<h3>1/25/2021</h3> 
- Created repository for the project. <br />
<h3>1/31/2021 </h3>
- Leyuan created a function called topple() to stimulate when the sandpile has more than 8 sands. Also, he has created helper functions functions - max and min. <br />
<h3>2/1/2021</h3> 
- Lee upload a file with some function in there. Initialize grid and output grid. There are also some if else statement in there which handle the argument of the input from user. <br />
- Blake merged the two files into one and updated the CHANGELOG <br />
- Added infinite loop to print the board <br />
- Added in functionality to handle the case of an input location greater than 8 <br />
- Updated README to coordinate with requirements <br />
<h3>2/2/2021</h3>
- Finished and submitted program

